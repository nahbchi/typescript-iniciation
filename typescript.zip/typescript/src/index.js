"use strict";
//tipos string, number, boolean
let nome;
let idade;
nome = "Juquinha";
idade = "17";
console.log(nome);
console.log(idade);
