//tipos string, number, boolean

let nome: string;
let idade: number;

nome = "Juquinha";
idade = "17";

console.log(nome);
console.log(idade);